describe 'we can verify employees list' do

    it 'get employees by id' do 
        @employee = Employee.get('/employee/98192')
        expect(@employee['employee_name']).to eq 'Julia29304'
    end
    
end