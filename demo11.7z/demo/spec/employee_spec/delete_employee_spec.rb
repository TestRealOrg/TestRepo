describe 'we can create new employees here' do
    it 'should create delete an employee' do
        @response = Employee.delete('delete/10')
    end
end