describe 'we can update new employees here' do
    it 'should update an employee' do
        @body = {
            "name":"testerson1",
            "salary":"123",
            "age":"23"
        }.to_json

        @response = Employee.put('/update/10', body: @body)
    end
end