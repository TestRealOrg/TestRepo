describe 'we can verify employees list' do

    it 'get employees lenght and verify' do 
        @employees = Employee.get('/employees')
        expect(@employees.length).to be > 100
    end

end