describe 'we can create new employees here' do
    before(:each) do 
        yaml_info = YAML.load(File.read('C:\\Users\\malencar\\Documents\\MeusProjetos\\Ruby\\demo\\data\\employees.yaml'))
        @employees = yaml_info[:employees]
    end
    
    it 'should create a new employee' do
        
        for e in @employees do
            @body = {
                "name": e[:name],
                "salary": e[:salary],
                "age": e[:age]
            }.to_json

            @response = Employee.post('/create', body: @body)
            puts @response.code
        end
    end
end