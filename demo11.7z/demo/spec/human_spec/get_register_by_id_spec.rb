describe 'we can verify employees list' do

    it 'get register by id' do 
        @employee = Human.get('/users/1')
        puts(@employee.parsed_response['data']['email'])
        expect(@employee.parsed_response['data']['email']).to eq('george.bluth@reqres.in')
    end
    
end