describe 'we can update any register' do
    it 'should update a register' do
        @body = {
            "name": "testerson2",
            "job": "api tester updated"
        }.to_json

        @response = Human.post('/users', body: @body)
        expect(@response.code).to eq 201
    end
end