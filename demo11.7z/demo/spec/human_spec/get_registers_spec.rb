describe 'we can verify register list' do

    it 'get registers lenght and verify' do 
        @employees = Human.get('/users')
        puts(@employees)
        expect(@employees.length).to be eq 2
    end

end