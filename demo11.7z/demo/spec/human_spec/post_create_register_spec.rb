describe 'we can create new employees here' do
    before(:each) do 
        yaml_info = YAML.load(File.read('C:\\Users\\malencar\\Documents\\MeusProjetos\\Ruby\\demo\\data\\human\\humans.yaml'))
        @humans = yaml_info[:humans]
    end
    
    it 'should create a new employee' do
        for h in @humans do
            @body = {
                "name": h[:name],
                "job": h[:job]
            }.to_json

            @response = Human.post('/users', body: @body)
            puts @response.code
            expect(@response.code).to eq 201
        end
    end
end