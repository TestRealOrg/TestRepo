require 'xmlsimple'

#hash = XmlSimple.xml_in('sample.xml')
#puts hash['CorporateHeader']

basedir = 'C:\\Users\\malencar\\Documents\\MeusProjetos\\Ruby\\demo\\policy_center\\static_forms'
files = Dir.glob("*.xml")

puts files
xml_hashes = []

files.each do |file_name|
    File.open(file_name) do |file|
        hash = XmlSimple.xml_in(file)
        xml_hashes.append(hash)
    end
end


puts xml_hashes[0]['PrintPayload'][1]['policyPeriod'][0]['AllCosts']
