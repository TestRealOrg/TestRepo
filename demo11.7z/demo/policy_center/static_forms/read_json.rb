require 'json'

basedir = 'C:\\Users\\malencar\\Documents\\MeusProjetos\\Ruby\\demo\\policy_center\\static_forms'
files = Dir.glob("*.json")

puts files
json_hashes = []

files.each do |file_name|
        file = File.read(file_name)
        hash = JSON.parse(file)
        json_hashes.append(hash)
end

for i in json_hashes do
    puts i['title']
    puts i['posts']['inside_info']
end

