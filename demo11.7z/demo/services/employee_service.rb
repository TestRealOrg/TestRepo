module Employee
    include HTTParty

    base_uri 'http://dummy.restapiexample.com/api/v1'

    format :json
    headers Accept:             '*/*',
            'Content-Type':     'application/json'
end