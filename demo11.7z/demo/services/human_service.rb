module Human
    include HTTParty

    base_uri 'https://reqres.in/api'

    format :json
    headers Accept:             '*/*',
            'Content-Type':     'application/json'
end